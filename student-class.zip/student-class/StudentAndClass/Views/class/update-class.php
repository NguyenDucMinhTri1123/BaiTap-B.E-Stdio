<?php 
    include_once "../Views/partial/head.php";
    include_once "../Views/partial/body.php";
?>


<body>
    <div class="container mt-5">
        <!-- Button trigger modal -->
        
        
    </div>
</body>


<div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Class Panel</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="admin">Home</a></li>
              <li class="breadcrumb-item active">Class Panel</li>
              <li class="breadcrumb-item active">Update</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
                <!-- Class infor -->
                <form method="POST" action="./class">
                    <div class="modal-header">
                        <h5 class="modal-title" id="studentLabel">Update Class</h5>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name_class" value="<?= $class->name ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Subject</label>
                            <select name="subject_id" class="form-control" >
                                <?php foreach($list_subject as $subject) {?>
                                    <?php if($class->subject_id==$subject->id){?>
                                        <option value="<?=$subject->id?>" <?php echo 'selected';?>>
                                            <?=$subject->name?>
                                        </option>
                                    <?php }else{ ?>
                                    <option value="<?=$subject->id?>"><?=$subject->name?></option>
                                <?php 
                                    } 
                                } 
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <input type="hidden" name="is_update_class" value="yes">
                            <input type="hidden" name="classID" value="<?= $class->id ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a href="./class"><button type="button" class="btn btn-secondary">Close</button></a>
                        
                    </div>
                </form>
                <!-- list student of class -->
                <form method="POST" action="./student">
                    <div class="modal-header">
                        <h5 class="modal-title" >Student List</h5>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Major</th>
                                        <th scope="col">Age</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($student_joined as $student) {
                                        
                                    ?>
                                    <tr>
                                        <th scope="row">
                                            <?= $student->id ?>
                                        </th>
                                        <td><?= $student->name ?></td>
                                        <td><?= $student->major_name ?></td>
                                        <td><?= $student->age ?></td>
                                        <td>DELETE</td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </form>
                <!-- list student havent join yet -->
                <form method="POST" action="./class">
                    <div class="modal-header">
                        <h5 class="modal-title" id="student_listLabel">Add Student</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Major</th>
                                <th scope="col">Age</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student) {
                            ?>
                            <tr>
                                <th scope="row">
                                    <input type="checkbox" name="student[]" value="<?= $student->id ?>">
                                </th>
                                <td><?= $student->name ?></td>
                                <td><?= $student->major_name ?></td>
                                <td><?= $student->age ?></td>
                                
                            </tr>
                            <?php } ?>

                        </tbody>
                    </table>
                    <div class="modal-footer">
                        <input type="hidden" name="is_add_student_to_class" value="yes">
                        <input type="hidden" name="classID" value="<?=$classID?>">
                        <a href="./class"><button type="button" class="btn btn-secondary">Close</button></a>
                        <button type="submit" class="btn btn-primary">ADD</button>
                    </div>
                </form>

            </div>
            <!-- /.card -->
          </div>
                                
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>





<?php 
    include_once "../Views/partial/footer.php";
?>   
    