<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php 
        include_once "header.php";
        include_once "sidebar.php";
    ?>
