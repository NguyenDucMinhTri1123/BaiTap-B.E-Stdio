<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="../Views/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../Views/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="../Views/dist/js/adminlte.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="../Views/plugins/chart.js/Chart.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../Views/dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../Views/dist/js/pages/dashboard3.js"></script>
<!-- custom script -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
</script>