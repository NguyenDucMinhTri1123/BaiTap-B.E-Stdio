  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Class Panel</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="admin">Home</a></li>
              <li class="breadcrumb-item active">Class Panel</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <div class="container mt-3">
      <!-- form to add a class -->
        <div class="modal fade" id="class" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="classLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" action="./class">
                        <div class="modal-header">
                            <h5 class="modal-title" id="classLabel">Add Class</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Name</label>
                                <input type="text" class="form-control" name="name_class">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Subject</label>
                                <select name="subject_id" class="form-control" >
                                    <?php foreach($list_subject as $subject) {?>
                                        <option value="<?=$subject->id?>"><?=$subject->name?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <input type="hidden" class="form-control" name="is_add_new_class" value="yes">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit_class" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- form to add subject -->
        <div class="modal fade" id="subject" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="subject" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" action="./class">
                        <div class="modal-header">
                            <h5 class="modal-title" id="subject">Add Subject</h5>
                            
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Name</label>
                                <input type="text" class="form-control" name="name_subject" value="">
                            </div>
                            <div class="mb-3">
                                <input type="hidden" name="is_add_subject" value="yes">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit_class" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
        <!-- few information -->
          <div class="col-lg-6">
            <div class="row">
              <!-- class number -->
              <div class=" col-lg-12 col-md-3">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">New Class</span>
                    <span class="info-box-number"><?= $_SESSION['num_class'];?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                  <!-- /.info-box -->
              </div>
              <!-- subject number -->
              <div class=" col-lg-12 col-md-3">
                <div class="info-box">
                  <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cog"></i></span>
                  <div class="info-box-content">
                    <span class="info-box-text">Subject</span>
                    <span class="info-box-number">
                      <?= $num_subject;?>
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
              <!-- alert -->
              <div class=" col-lg-12 col-md-3">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-users"></i></span>
                  <div class="info-box-content">
                    <span class="info-box-text">
                    <?php 
                      if(isset($delete_class_result)){
                          echo $delete_class_result;
                          $delete_class_result='';
                      }
                    ?>
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                  <!-- /.info-box -->
              </div>
              
            </div>
          </div>
          <!-- subject table -->
          <div class="col-lg-6">
            <div class="card">
                <div class="card-header border-0 d-flex justify-content-between">
                  <h3 class="card-title">Subject List</h3>
                  <div class="card-tools">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#subject">
                      Add Subject
                    </button>
                  </div>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-striped table-valign-middle ">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i=1;
                        foreach ($list_subject as $subject) {
                        ?>
                        <tr>
                          <form method="POST" action="./class" onclick="return confirm('Are you sure?');">
                            <th scope="row"><?= $i++; ?></th>
                            <td><input type="text" class="" name="subject_name" value="<?= $subject->name ?>"></td>
                            <td class="d-flex">
                              <input type="hidden" name="subjectID" value="<?= $subject->id ?>">
                              <input type="hidden" name="is_update_subject" value="yes">
                              <button type="submit" class="btn btn-success">UPDATE</button>
                            </td>
                            </form>
                            <td>
                              <form method="POST" action="./class"> 
                                <input type="hidden" name="subjectID" value="<?= $subject->id ?>">
                                <input type="hidden" name="is_delete_subject" value="yes">
                                <button type="submit" class="btn  btn-danger">DELETE</button>
                              </form>
                            </td>
                        </tr>
                        <?php } ?>

                    </tbody>
                  </table>
                </div>
              </div>
          </div>
            <!-- class list table -->
          <div class="col-lg-12">
            <div class="card">
              <div class="card-header border-0 d-flex justify-content-between">
                <h3 class="card-title">Class List</h3>
                <button type="button" class="btn btn-primary " data-bs-toggle="modal" data-bs-target="#class">
                  Add Class
                </button>
              </div>
              <div class="card-body table-responsive p-0">
                
                <table class="table table-striped table-valign-middle col-12">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Subject</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i=1;
                        foreach ($list_class as $class) {
                        ?>
                        <tr>
                            <th scope="row"><?= $i++; ?></th>
                            <td><?= $class->name ?></td>
                            <td><?= $class->subject_name ?></td>
                            <td class="d-flex">
                              <form method="POST" action="./class" onclick="return confirm('Are you sure?');">
                                <input type="hidden" name="classID" value="<?= $class->id ?>">
                                <input type="hidden" name="is_delete_class" value="yes">
                                <button type="submit" class="btn btn-danger">DELETE</button>
                              </form>
                              <form method="POST" action="./class"> 
                                <input type="hidden" name="classID" value="<?= $class->id ?>">
                                <input type="hidden" name="is_start_update_class" value="yes">
                                <button type="submit" class="btn btn-success">UPDATE</button>
                              </form>
                            </td>
                        </tr>
                        <?php } ?>

                    </tbody>
                </table>
              </div>
            </div>
            <!-- /.card -->
          </div>

        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>