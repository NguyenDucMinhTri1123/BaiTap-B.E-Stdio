<?php 
    include_once "../Views/partial/head.php";
    include_once "../Views/partial/body.php";
    include_once "main-content.php";
    include_once "../Views/partial/footer.php";
?>