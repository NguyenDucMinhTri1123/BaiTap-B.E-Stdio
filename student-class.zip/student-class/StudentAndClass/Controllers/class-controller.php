<?php 
    class ClassController{
        static public function home(){
            try {

                
                $list_class = Classes::getList();
                $list_subject=subject::get_list();
                $num_class=count($list_class);
                $num_subject=count($list_subject);
                $_SESSION['num_class']=$num_class;

                include_once "../Views/class/index.php";
            } catch (\Throwable $th) {
                echo $th->getMessage();
            }
        }
        static public function check($request){
            try {
                if(isset($request['is_delete_class'])){
                
                    $classID = $request['classID'];
                    $check_exits_student =Classes::count_student($classID);
                    if($check_exits_student['COUNT(*)']>0){
                        $num=$check_exits_student['COUNT(*)'];
                        $delete_class_result="Lớp này đang có $num học sinh <br>
                        Không thể xóa lớp học đang có học sinh";
                    }
                    $result= Classes::delete($classID);
                }
                else if(isset($request['is_delete_subject'])){
                    $id=$request['subjectID'];
                    $check_exits_in_class=subject::count_class($id);
                    if($check_exits_in_class['COUNT(*)']>0){
                        $num=$check_exits_in_class['COUNT(*)'];
                        $delete_subject_result="Có $num sinh viên đang theo học chuyên ngành này
                        <br> không thể xóa";
                    }
                    $result=subject::delete($id);
                }
                else if(isset($request['is_add_new_class'])){
                    if(!$request['name_class'] || !$request['subject_id']){
                        echo "Dữ liệu không hợp lệ";
                        return;
                    }else{
                        
                        $class = new Classes(null, $request['name_class'], $request['subject_id'],"");
                        $result= Classes::add($class);
                    }
                }
                else if(isset($request['is_update_class'])){
                    $classID = $request['classID'];
                    $nameClass = $request['name_class'];
                    $subject_id = $request['subject_id'];
                    $class = new Classes($classID,$nameClass,$subject_id,"");
                    $result= Classes::update($class);
                }
                else if(isset($request['is_add_student_to_class'])){
                    $classID=$request['classID'];
                    foreach($request['student'] as $student){
                        $studentID = $student;
                        $result = Classes::add_student($classID,$studentID);
                    }
                }
                else if(isset($request['is_add_subject'])){
                    $subject= new subject("",$request['name_subject']);
                    $result=subject::add($subject);
                }
                else if(isset($request['is_update_subject'])){
                    $subjectID=$request['subjectID'];
                    $subject_name=$request['subject_name'];
                    $subject= new subject($subjectID,$subject_name);
                    $result=subject::update($subject);
                }
                else if(isset($request['is_start_update_class'])){
                    $classID=$request['classID'];
                    $list_subject=subject::get_list();
                    $class=Classes::getOne($classID);
                    $student_joined=Classes::list_student_of_class($classID);
                    $students=Classes::check_student_not_join($classID);
                }
                $list_class = Classes::getList();
                $list_subject=subject::get_list();
                $num_class=count($list_class);
                $num_subject=count($list_subject);
                $_SESSION['num_class']=$num_class;
                if(isset($request['is_add_student_to_class'])){
                    $classID=$request['classID'];
                    $list_subject=subject::get_list();
                    $class=Classes::getOne($classID);
                    $student_joined=Classes::list_student_of_class($classID);
                    $students=Classes::check_student_not_join($classID);
                    include_once "../Views/class/update-class.php";
                }
                else if(isset($request['is_start_update_class'])){
                    include_once "../Views/class/update-class.php";
                }else
                include_once "../Views/class/index.php";
            } catch (\Throwable $th) {
                echo $th->getMessage();
            }
        }
    }
?>