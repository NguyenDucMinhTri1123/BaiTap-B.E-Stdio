<?php 
include_once "../Models/DBs.php";
include_once "../Models/Student.php";
include_once "../Models/Class.php";
include_once "../Models/major.php";
    class StudentController{
        static public function check($request){
            try {
                
                if(isset($request['is_delete_student'])){
                
                    $studentID = $request['studentID'];
                    $check_exits_class =Student::count_class($studentID);
                    if($check_exits_class['COUNT(*)']>0){
                        $num=$check_exits_class['COUNT(*)'];
                        $detele_student_result="Học sinh này đang tham gia $num Lớp học <br>
                        Không thể xóa học sinh đang tham gia lớp học";
                    }
                    
                    $result= Student::delete($studentID);
                }
                else if(isset($request['is_delete_major'])){
                    $id=$request['majorID'];
                    $check_exits_in_student=major::count_student($id);
                    if($check_exits_in_student['COUNT(*)']>0){
                        $num=$check_exits_in_student['COUNT(*)'];
                        $delete_major_result="Có $num sinh viên đang theo học chuyên ngành này
                        <br> không thể xóa";
                    }
                   
                    $result=major::delete($id);
                }
                else if(isset($request['is_add_new_student'])){
                    if (!$request['name_student'] || !$request['age'] || !$request['major_id']) {
                        echo "Dữ liệu không hợp lệ";
                        return;
                    }else{
                        $student = new Student(null, $request['name_student'], $request['age'], $request['major_id'],"");
                        $result= TotalController::add_student($student);
                    }
                    
                }
                else if(isset($request['is_add_major'])){
                    $major= new major("",$request['name_major']);
                    $result=TotalController::add_major($major);
                    
                }
                else if(isset($request['is_start_update_student'])){
                    $studentID = $request['studentID'];
                    $list_major= major::get_list();
                    $student = Student::getOne($studentID);
                    // data for list class that not joined
                    $studentID = $request['studentID'];
                    $class = Student::check_class_not_join($studentID);
                    $class_joined = Student::list_class_of_student($studentID);
                }
                else if(isset($request['is_update_student'])){
                    $studentID = $request['studentID'];
                    $name = $request['name'];
                    $age = $request['age'];
                    $major_id= $request['major_id'];
                    $student = new Student($studentID,$name,$age,$major_id,"");
                    $result= TotalController::update_student($student);
                    
                }
                else if(isset($request['is_join_class'])){
                    $studentID=$request['studentID'];
                    if(isset($request['classes']))
                    foreach($request['classes'] as $class){
                        $classID = $class;
                        $result = Student::join_class($classID,$studentID);
                    }
                }
                else if(isset($request['is_update_major'])){
                    $majorID=$request['majorID'];
                    $major_name=$request['major_name'];
                    $major=new major($majorID,$major_name);
                    $result=major::update($major);
                }
                $list_student = Student::getList();
                $list_major= major::get_list();
                $num_student = count($list_student);
                $num_major=count($list_major);
                //check condition to redirect
                if(isset($request['is_start_update_student'])){
                    include_once "../Views/student/update-student.php";
                }
                else if(isset($request['is_join_class'])){
                    $studentID = $request['studentID'];
                    $list_major= major::get_list();
                    $student = Student::getOne($studentID);
                    // data for list class that not joined
                    $class = Student::check_class_not_join($studentID);
                    $class_joined = Student::list_class_of_student($studentID);
                    include_once "../Views/student/update-student.php";
                }else
                include_once "../Views/student/index.php";
            } catch (\Throwable $th) {
                echo $th->getMessage();
            }
        }
        static public function home(){
            try {
                $list_student = Student::getList();
                $list_major= major::get_list();
                $list_class = Classes::getList();
                $list_subject=subject::get_list();
                $_SESSION['num_class']=count($list_class);
                $_SESSION['num_subject']=count($list_subject);
                $_SESSION['num_student']= count($list_student);
                $_SESSION['num_major']=count($list_major);
                include_once "../Views/student/index.php";
            } catch (\Throwable $th) {
                echo $th->getMessage();
            }
        }

    }
?>